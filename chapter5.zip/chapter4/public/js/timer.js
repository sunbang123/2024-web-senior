// var counter = 0;
// var interval = setInterval(function () {
//     console.log(counter++);
// }, 1000);

// 인터벌을 멈추고 싶을때
// clearInterval(interval);

setTimeout(function () {
    console.log('1초가 지났습니다.');
}, 1000);